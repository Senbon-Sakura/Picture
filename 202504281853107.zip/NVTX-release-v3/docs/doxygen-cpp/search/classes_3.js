var searchData=
[
  ['event_5fattributes_0',['event_attributes',['../classnvtx3_1_1v1_1_1event__attributes.html',1,'nvtx3::event_attributes'],['../classnvtx3_1_1v1_1_1event__attributes.html',1,'nvtx3::v1::event_attributes']]]
];
