var searchData=
[
  ['range_5fhandle_0',['range_handle',['../structnvtx3_1_1v1_1_1range__handle.html',1,'nvtx3::range_handle'],['../structnvtx3_1_1v1_1_1range__handle.html',1,'nvtx3::v1::range_handle']]],
  ['registered_5fstring_5fin_1',['registered_string_in',['../classnvtx3_1_1v1_1_1registered__string__in.html',1,'nvtx3::registered_string_in&lt; D &gt;'],['../classnvtx3_1_1v1_1_1registered__string__in.html',1,'nvtx3::v1::registered_string_in&lt; D &gt;']]],
  ['rgb_2',['rgb',['../structnvtx3_1_1v1_1_1rgb.html',1,'nvtx3::rgb'],['../structnvtx3_1_1v1_1_1rgb.html',1,'nvtx3::v1::rgb']]]
];
