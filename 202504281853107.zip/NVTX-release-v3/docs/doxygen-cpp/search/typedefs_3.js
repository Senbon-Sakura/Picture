var searchData=
[
  ['registered_5fstring_0',['registered_string',['../nvtx3_8hpp.html#a952cb27f352570421161c01763effe63',1,'nvtx3::v1']]]
];
