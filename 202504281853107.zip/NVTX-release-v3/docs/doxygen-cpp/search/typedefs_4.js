var searchData=
[
  ['scoped_5frange_0',['scoped_range',['../nvtx3_8hpp.html#a8e124f3d438e512b586415f1ac2b9677',1,'nvtx3::v1']]]
];
