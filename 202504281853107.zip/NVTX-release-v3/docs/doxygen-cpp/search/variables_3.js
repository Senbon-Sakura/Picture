var searchData=
[
  ['red_0',['red',['../structnvtx3_1_1v1_1_1rgb.html#a0ba9bc1b62447a26b2763c2e0f89db58',1,'nvtx3::v1::rgb']]]
];
