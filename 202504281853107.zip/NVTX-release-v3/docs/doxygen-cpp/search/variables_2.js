var searchData=
[
  ['green_0',['green',['../structnvtx3_1_1v1_1_1rgb.html#a3392ec8cdbe24db639f6bc57904647c3',1,'nvtx3::v1::rgb']]]
];
