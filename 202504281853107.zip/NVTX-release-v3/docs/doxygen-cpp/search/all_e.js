var searchData=
[
  ['value_5ftype_0',['value_type',['../classnvtx3_1_1v1_1_1color.html#a6327e421cdd233398693a2804aea942f',1,'nvtx3::v1::color::value_type()'],['../structnvtx3_1_1v1_1_1range__handle.html#a77be25af5cf21fde96c18bf30727f109',1,'nvtx3::v1::range_handle::value_type()']]]
];
