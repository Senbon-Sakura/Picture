var searchData=
[
  ['domain_0',['domain',['../classnvtx3_1_1v1_1_1domain.html',1,'nvtx3::domain'],['../classnvtx3_1_1v1_1_1domain.html',1,'nvtx3::v1::domain']]],
  ['get_3c_20domain_3a_3aglobal_20_3e_1',['get&lt; domain::global &gt;',['../nvtx3_8hpp.html#a2035d9aeb0dd80cb41c64352783171b9',1,'nvtx3::v1']]]
];
