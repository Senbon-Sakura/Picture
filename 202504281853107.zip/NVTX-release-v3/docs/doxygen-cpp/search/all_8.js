var searchData=
[
  ['named_5fcategory_0',['named_category',['../nvtx3_8hpp.html#a5ffa040266b85b6fb131dcb9ade33a0a',1,'nvtx3::v1']]],
  ['named_5fcategory_5fin_1',['named_category_in',['../classnvtx3_1_1v1_1_1named__category__in.html#a7fe4261f6a0b9d1cfb6e566d8ff2135f',1,'nvtx3::v1::named_category_in::named_category_in(id_type id, char const *name) noexcept'],['../classnvtx3_1_1v1_1_1named__category__in.html#a0b8ac1f00f1c0686858a20884c8eb19a',1,'nvtx3::v1::named_category_in::named_category_in(id_type id, wchar_t const *name) noexcept'],['../classnvtx3_1_1v1_1_1named__category__in.html',1,'nvtx3::named_category_in&lt; D &gt;'],['../classnvtx3_1_1v1_1_1named__category__in.html',1,'nvtx3::v1::named_category_in&lt; D &gt;']]],
  ['nvtx_20c_2b_2b_20api_20reference_2',['NVTX C++ API Reference',['../index.html',1,'']]],
  ['nvtx3_2ehpp_3',['nvtx3.hpp',['../nvtx3_8hpp.html',1,'']]],
  ['nvtx3_5fcpp_5finlined_5fversion_5fmajor_4',['NVTX3_CPP_INLINED_VERSION_MAJOR',['../nvtx3_8hpp.html#ac2d95bad5f74d08ca6660da2a92a4463',1,'nvtx3.hpp']]],
  ['nvtx3_5fcpp_5finlined_5fversion_5fminor_5',['NVTX3_CPP_INLINED_VERSION_MINOR',['../nvtx3_8hpp.html#abb380e5bd6d9e68f116ad5fd2758f861',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_6',['NVTX3_V1_FUNC_RANGE',['../nvtx3_8hpp.html#a9f0dbc21588c8d0f6ee728fdf5289490',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fif_7',['NVTX3_V1_FUNC_RANGE_IF',['../nvtx3_8hpp.html#a7f4e78b0ede77382c2c09fa007c5963e',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fif_5fin_8',['NVTX3_V1_FUNC_RANGE_IF_IN',['../nvtx3_8hpp.html#af6fecf49b25b2364e548f9786136fb95',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fin_9',['NVTX3_V1_FUNC_RANGE_IN',['../nvtx3_8hpp.html#a58b4c0fa6be7f4754f8e73bcbf6fd1af',1,'nvtx3.hpp']]]
];
