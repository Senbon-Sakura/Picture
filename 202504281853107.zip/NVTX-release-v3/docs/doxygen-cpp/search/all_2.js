var searchData=
[
  ['category_0',['category',['../classnvtx3_1_1v1_1_1category.html#a16b26c66ef40850b7bf79fb8e8b9ccec',1,'nvtx3::v1::category::category()'],['../classnvtx3_1_1v1_1_1category.html',1,'nvtx3::category'],['../classnvtx3_1_1v1_1_1category.html',1,'nvtx3::v1::category']]],
  ['color_1',['color',['../classnvtx3_1_1v1_1_1color.html#a671a9e63379a2896f5c689fb0a37f0a9',1,'nvtx3::v1::color::color(value_type hex_code) noexcept'],['../classnvtx3_1_1v1_1_1color.html#abd11ca09f1b3a66041cea45d4141dc37',1,'nvtx3::v1::color::color(argb argb_) noexcept'],['../classnvtx3_1_1v1_1_1color.html#a47084ed086b5071cd7b070b0a4611e24',1,'nvtx3::v1::color::color(rgb rgb_) noexcept'],['../classnvtx3_1_1v1_1_1color.html',1,'nvtx3::color'],['../classnvtx3_1_1v1_1_1color.html',1,'nvtx3::v1::color']]],
  ['component_5ftype_2',['component_type',['../structnvtx3_1_1v1_1_1rgb.html#afc2175c4660eb39a9d905528d02fe1b8',1,'nvtx3::v1::rgb']]]
];
