var searchData=
[
  ['named_5fcategory_5fin_0',['named_category_in',['../classnvtx3_1_1v1_1_1named__category__in.html#a7fe4261f6a0b9d1cfb6e566d8ff2135f',1,'nvtx3::v1::named_category_in::named_category_in(id_type id, char const *name) noexcept'],['../classnvtx3_1_1v1_1_1named__category__in.html#a0b8ac1f00f1c0686858a20884c8eb19a',1,'nvtx3::v1::named_category_in::named_category_in(id_type id, wchar_t const *name) noexcept']]]
];
