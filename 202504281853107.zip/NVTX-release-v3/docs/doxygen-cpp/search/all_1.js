var searchData=
[
  ['blue_0',['blue',['../structnvtx3_1_1v1_1_1rgb.html#a0d5c114d99170ed8922dbdd743ec580f',1,'nvtx3::v1::rgb']]]
];
