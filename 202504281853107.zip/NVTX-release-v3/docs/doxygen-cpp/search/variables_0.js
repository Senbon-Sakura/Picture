var searchData=
[
  ['alpha_0',['alpha',['../structnvtx3_1_1v1_1_1argb.html#af2b1b511212ab1c6cb1f5a340dc6b339',1,'nvtx3::v1::argb']]]
];
