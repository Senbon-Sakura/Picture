var searchData=
[
  ['_7escoped_5frange_5fin_0',['~scoped_range_in',['../classnvtx3_1_1v1_1_1scoped__range__in.html#aebf31fd1548c4bf5196332db9ee90fb1',1,'nvtx3::v1::scoped_range_in']]],
  ['_7eunique_5frange_5fin_1',['~unique_range_in',['../classnvtx3_1_1v1_1_1unique__range__in.html#a931bde31ac0aeb60e8f3050a29c60f83',1,'nvtx3::v1::unique_range_in']]]
];
