var searchData=
[
  ['argb_0',['argb',['../structnvtx3_1_1v1_1_1argb.html#afe825f33bf3e68178c1df87d86ec9d93',1,'nvtx3::v1::argb']]]
];
