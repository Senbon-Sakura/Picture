var searchData=
[
  ['category_0',['category',['../classnvtx3_1_1v1_1_1category.html',1,'nvtx3::category'],['../classnvtx3_1_1v1_1_1category.html',1,'nvtx3::v1::category']]],
  ['color_1',['color',['../classnvtx3_1_1v1_1_1color.html',1,'nvtx3::color'],['../classnvtx3_1_1v1_1_1color.html',1,'nvtx3::v1::color']]]
];
