var searchData=
[
  ['component_5ftype_0',['component_type',['../structnvtx3_1_1v1_1_1rgb.html#afc2175c4660eb39a9d905528d02fe1b8',1,'nvtx3::v1::rgb']]]
];
