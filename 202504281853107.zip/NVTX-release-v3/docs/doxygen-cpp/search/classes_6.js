var searchData=
[
  ['named_5fcategory_5fin_0',['named_category_in',['../classnvtx3_1_1v1_1_1named__category__in.html',1,'nvtx3::named_category_in&lt; D &gt;'],['../classnvtx3_1_1v1_1_1named__category__in.html',1,'nvtx3::v1::named_category_in&lt; D &gt;']]]
];
