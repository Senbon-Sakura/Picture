var searchData=
[
  ['operator_20bool_0',['operator bool',['../structnvtx3_1_1v1_1_1range__handle.html#ab622758fb9654b36c018b0c9aa91679a',1,'nvtx3::v1::range_handle']]],
  ['operator_20new_1',['operator new',['../classnvtx3_1_1v1_1_1scoped__range__in.html#aaa2e0c47375a578c7f772501905b8d22',1,'nvtx3::v1::scoped_range_in']]],
  ['operator_20nvtxdomainhandle_5ft_2',['operator nvtxDomainHandle_t',['../classnvtx3_1_1v1_1_1domain.html#aa569f92fc6b823641524ba5daa5baa66',1,'nvtx3::v1::domain']]],
  ['operator_21_3d_3',['operator!=',['../nvtx3_8hpp.html#aaaae235fe6980a2ac95eb4f35d6e9ad1',1,'nvtx3::v1']]],
  ['operator_3d_4',['operator=',['../classnvtx3_1_1v1_1_1unique__range__in.html#ac898edbc15c5426c6095c6a53f27951f',1,'nvtx3::v1::unique_range_in::operator=(unique_range_in &amp;&amp;other) noexcept=default'],['../classnvtx3_1_1v1_1_1unique__range__in.html#a22402183d4e9db06a6b6a00e9218fcab',1,'nvtx3::v1::unique_range_in::operator=(unique_range_in const &amp;)=delete']]],
  ['operator_3d_3d_5',['operator==',['../nvtx3_8hpp.html#aa2016d0df543887a838402751356433d',1,'nvtx3::v1']]]
];
