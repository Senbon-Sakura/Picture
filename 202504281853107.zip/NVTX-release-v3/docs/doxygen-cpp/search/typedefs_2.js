var searchData=
[
  ['named_5fcategory_0',['named_category',['../nvtx3_8hpp.html#a5ffa040266b85b6fb131dcb9ade33a0a',1,'nvtx3::v1']]]
];
