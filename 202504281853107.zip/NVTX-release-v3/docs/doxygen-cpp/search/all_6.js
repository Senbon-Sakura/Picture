var searchData=
[
  ['id_5ftype_0',['id_type',['../classnvtx3_1_1v1_1_1category.html#a93b9c6f1e074a03ee50287c9c6414bc0',1,'nvtx3::v1::category']]]
];
