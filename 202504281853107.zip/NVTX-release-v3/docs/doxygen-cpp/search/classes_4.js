var searchData=
[
  ['global_0',['global',['../structnvtx3_1_1v1_1_1domain_1_1global.html',1,'nvtx3::v1::domain']]]
];
