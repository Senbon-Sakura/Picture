var searchData=
[
  ['message_0',['message',['../classnvtx3_1_1v1_1_1message.html',1,'nvtx3::message'],['../classnvtx3_1_1v1_1_1message.html',1,'nvtx3::v1::message']]]
];
