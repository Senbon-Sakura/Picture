var searchData=
[
  ['scoped_5frange_5fin_0',['scoped_range_in',['../classnvtx3_1_1v1_1_1scoped__range__in.html#a25eff24202b7021ced3481b29c1768c8',1,'nvtx3::v1::scoped_range_in::scoped_range_in(event_attributes const &amp;attr) noexcept'],['../classnvtx3_1_1v1_1_1scoped__range__in.html#a53b3c3d95b29dfc31db2df290804df65',1,'nvtx3::v1::scoped_range_in::scoped_range_in(Args const &amp;... args) noexcept'],['../classnvtx3_1_1v1_1_1scoped__range__in.html#a72417f5a5f0ecf2b67551880bdd28955',1,'nvtx3::v1::scoped_range_in::scoped_range_in() noexcept']]],
  ['start_5frange_1',['start_range',['../nvtx3_8hpp.html#a944d0beb92c70e5d3842c5dc4fca81ec',1,'nvtx3::v1::start_range(event_attributes const &amp;attr) noexcept'],['../nvtx3_8hpp.html#a7484c890617a91bbbb998b793b59584e',1,'nvtx3::v1::start_range(Args const &amp;... args) noexcept']]],
  ['start_5frange_5fin_2',['start_range_in',['../nvtx3_8hpp.html#a58d393b13ffc2fe5f44b0171be0bec23',1,'nvtx3::v1::start_range_in(event_attributes const &amp;attr) noexcept'],['../nvtx3_8hpp.html#a277b16a1aadc6e8b40e720847b5fb124',1,'nvtx3::v1::start_range_in(Args const &amp;... args) noexcept']]]
];
