var searchData=
[
  ['end_5frange_0',['end_range',['../nvtx3_8hpp.html#aec1adbeb9e44752027d2ede89f1f0dba',1,'nvtx3::v1']]],
  ['end_5frange_5fin_1',['end_range_in',['../nvtx3_8hpp.html#a0ef24a4252e5cc6267766410a03dcebb',1,'nvtx3::v1']]],
  ['event_5fattributes_2',['event_attributes',['../classnvtx3_1_1v1_1_1event__attributes.html#af9b06fcd1d0bb4b8739009b3b00ef34d',1,'nvtx3::v1::event_attributes::event_attributes() noexcept'],['../classnvtx3_1_1v1_1_1event__attributes.html#a27ef8784b11bb620cd597ea55a781e02',1,'nvtx3::v1::event_attributes::event_attributes(category const &amp;c, Args const &amp;... args) noexcept'],['../classnvtx3_1_1v1_1_1event__attributes.html#a14e581407cea05235f0f814f4043c656',1,'nvtx3::v1::event_attributes::event_attributes(color const &amp;c, Args const &amp;... args) noexcept'],['../classnvtx3_1_1v1_1_1event__attributes.html#ac16fc2b8249f503ff89ee14a9fdb63fd',1,'nvtx3::v1::event_attributes::event_attributes(payload const &amp;p, Args const &amp;... args) noexcept'],['../classnvtx3_1_1v1_1_1event__attributes.html#acccdd768a4fbe2234d151e8a8443f44f',1,'nvtx3::v1::event_attributes::event_attributes(message const &amp;m, Args const &amp;... args) noexcept']]]
];
