var searchData=
[
  ['alpha_0',['alpha',['../structnvtx3_1_1v1_1_1argb.html#af2b1b511212ab1c6cb1f5a340dc6b339',1,'nvtx3::v1::argb']]],
  ['argb_1',['argb',['../structnvtx3_1_1v1_1_1argb.html#afe825f33bf3e68178c1df87d86ec9d93',1,'nvtx3::v1::argb::argb()'],['../structnvtx3_1_1v1_1_1argb.html',1,'nvtx3::argb'],['../structnvtx3_1_1v1_1_1argb.html',1,'nvtx3::v1::argb']]]
];
