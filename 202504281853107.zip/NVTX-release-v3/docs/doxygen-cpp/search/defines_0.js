var searchData=
[
  ['nvtx3_5fcpp_5finlined_5fversion_5fmajor_0',['NVTX3_CPP_INLINED_VERSION_MAJOR',['../nvtx3_8hpp.html#ac2d95bad5f74d08ca6660da2a92a4463',1,'nvtx3.hpp']]],
  ['nvtx3_5fcpp_5finlined_5fversion_5fminor_1',['NVTX3_CPP_INLINED_VERSION_MINOR',['../nvtx3_8hpp.html#abb380e5bd6d9e68f116ad5fd2758f861',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_2',['NVTX3_V1_FUNC_RANGE',['../nvtx3_8hpp.html#a9f0dbc21588c8d0f6ee728fdf5289490',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fif_3',['NVTX3_V1_FUNC_RANGE_IF',['../nvtx3_8hpp.html#a7f4e78b0ede77382c2c09fa007c5963e',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fif_5fin_4',['NVTX3_V1_FUNC_RANGE_IF_IN',['../nvtx3_8hpp.html#af6fecf49b25b2364e548f9786136fb95',1,'nvtx3.hpp']]],
  ['nvtx3_5fv1_5ffunc_5frange_5fin_5',['NVTX3_V1_FUNC_RANGE_IN',['../nvtx3_8hpp.html#a58b4c0fa6be7f4754f8e73bcbf6fd1af',1,'nvtx3.hpp']]]
];
