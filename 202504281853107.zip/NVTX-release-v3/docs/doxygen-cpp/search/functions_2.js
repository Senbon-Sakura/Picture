var searchData=
[
  ['get_3c_20domain_3a_3aglobal_20_3e_0',['get&lt; domain::global &gt;',['../nvtx3_8hpp.html#a2035d9aeb0dd80cb41c64352783171b9',1,'nvtx3::v1']]]
];
