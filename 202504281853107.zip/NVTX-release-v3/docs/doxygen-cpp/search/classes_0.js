var searchData=
[
  ['argb_0',['argb',['../structnvtx3_1_1v1_1_1argb.html',1,'nvtx3::argb'],['../structnvtx3_1_1v1_1_1argb.html',1,'nvtx3::v1::argb']]]
];
