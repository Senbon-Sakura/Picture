var searchData=
[
  ['scoped_5frange_5fin_0',['scoped_range_in',['../classnvtx3_1_1v1_1_1scoped__range__in.html',1,'nvtx3::scoped_range_in&lt; D &gt;'],['../classnvtx3_1_1v1_1_1scoped__range__in.html',1,'nvtx3::v1::scoped_range_in&lt; D &gt;']]]
];
