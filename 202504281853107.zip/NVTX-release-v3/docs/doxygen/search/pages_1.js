var searchData=
[
  ['synchronization_0',['Synchronization',['../_p_a_g_e__s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html',1,'']]]
];
