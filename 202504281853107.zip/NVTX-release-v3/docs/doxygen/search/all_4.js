var searchData=
[
  ['identifier_5ft_0',['identifier_t',['../unionnvtx_resource_attributes__v0_1_1identifier__t.html',1,'nvtxResourceAttributes_v0']]],
  ['identifiertype_1',['identifierType',['../structnvtx_resource_attributes__v0.html#acec361e5bafce002e93a604e36bdf31b',1,'nvtxResourceAttributes_v0']]]
];
