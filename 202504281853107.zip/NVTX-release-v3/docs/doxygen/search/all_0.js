var searchData=
[
  ['category_0',['category',['../structnvtx_event_attributes__v2.html#afb670b7abeb2d588c7157c08248e3665',1,'nvtxEventAttributes_v2']]],
  ['color_1',['color',['../structnvtx_event_attributes__v2.html#aeddc617cf06c8e83dbfaf3968ad04a5d',1,'nvtxEventAttributes_v2']]],
  ['colortype_2',['colorType',['../structnvtx_event_attributes__v2.html#a67e51604f4f074d3a896a2475b36a8f0',1,'nvtxEventAttributes_v2']]]
];
