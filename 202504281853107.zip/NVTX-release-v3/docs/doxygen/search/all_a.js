var searchData=
[
  ['version_0',['version',['../structnvtx_event_attributes__v2.html#a307b3b9949304b301e1b6d1346c71530',1,'nvtxEventAttributes_v2::version()'],['../structnvtx_resource_attributes__v0.html#a6aa99e7e990a00e128b80bf9199bcd7a',1,'nvtxResourceAttributes_v0::version()'],['../structnvtx_sync_user_attributes__v0.html#a5f765c007f7b252496240c4fd9e833b8',1,'nvtxSyncUserAttributes_v0::version()']]]
];
