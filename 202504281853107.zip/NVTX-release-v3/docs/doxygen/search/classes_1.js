var searchData=
[
  ['nvtxeventattributes_5fv2_0',['nvtxEventAttributes_v2',['../structnvtx_event_attributes__v2.html',1,'']]],
  ['nvtxmessagevalue_5ft_1',['nvtxMessageValue_t',['../unionnvtx_message_value__t.html',1,'']]],
  ['nvtxresourceattributes_5fv0_2',['nvtxResourceAttributes_v0',['../structnvtx_resource_attributes__v0.html',1,'']]],
  ['nvtxsyncuserattributes_5fv0_3',['nvtxSyncUserAttributes_v0',['../structnvtx_sync_user_attributes__v0.html',1,'']]]
];
