var searchData=
[
  ['payload_5ft_0',['payload_t',['../unionnvtx_event_attributes__v2_1_1payload__t.html',1,'nvtxEventAttributes_v2']]],
  ['payloadtype_1',['payloadType',['../structnvtx_event_attributes__v2.html#ab92717e2aed2888cd99ecdf6c4681e45',1,'nvtxEventAttributes_v2']]]
];
