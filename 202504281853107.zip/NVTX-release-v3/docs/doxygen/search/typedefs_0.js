var searchData=
[
  ['nvtxresourcesyncandroidtype_5ft_0',['nvtxResourceSyncAndroidType_t',['../group___s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html#ga2601dab93020f0a531dbaa78ef6a90f7',1,'nvToolsExtSync.h']]],
  ['nvtxsyncuser_5ft_1',['nvtxSyncUser_t',['../group___s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html#ga79ab2a04ba725255a14f1d2a34b92f9f',1,'nvToolsExtSync.h']]]
];
