var searchData=
[
  ['size_0',['size',['../structnvtx_event_attributes__v2.html#a90b5726d65e2665b558668eada26ffb9',1,'nvtxEventAttributes_v2::size()'],['../structnvtx_resource_attributes__v0.html#a3f251637098a16e51e3dd16f6f223282',1,'nvtxResourceAttributes_v0::size()'],['../structnvtx_sync_user_attributes__v0.html#ad55d1c1734d77c23863234c28667a4e1',1,'nvtxSyncUserAttributes_v0::size()']]],
  ['string_20registration_1',['String Registration',['../group___s_t_r_i_n_g___r_e_g_i_s_t_r_a_t_i_o_n.html',1,'']]],
  ['synchronization_2',['Synchronization',['../_p_a_g_e__s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html',1,'(Global Namespace)'],['../group___s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html',1,'(Global Namespace)']]]
];
