var searchData=
[
  ['payloadtype_0',['payloadType',['../structnvtx_event_attributes__v2.html#ab92717e2aed2888cd99ecdf6c4681e45',1,'nvtxEventAttributes_v2']]]
];
