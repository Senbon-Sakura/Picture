var searchData=
[
  ['identifier_5ft_0',['identifier_t',['../unionnvtx_resource_attributes__v0_1_1identifier__t.html',1,'nvtxResourceAttributes_v0']]]
];
