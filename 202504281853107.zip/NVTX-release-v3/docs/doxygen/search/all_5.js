var searchData=
[
  ['markers_20and_20ranges_0',['Markers and Ranges',['../group___m_a_r_k_e_r_s___a_n_d___r_a_n_g_e_s.html',1,'']]],
  ['message_1',['message',['../structnvtx_event_attributes__v2.html#ac2c886998107953b9ca44c096650ac6f',1,'nvtxEventAttributes_v2::message()'],['../structnvtx_resource_attributes__v0.html#a6fb8c53dcd2860bada12560d5b2e586f',1,'nvtxResourceAttributes_v0::message()'],['../structnvtx_sync_user_attributes__v0.html#af0a877617fbf058cc2b6ee5c97a28ca6',1,'nvtxSyncUserAttributes_v0::message()']]],
  ['messagetype_2',['messageType',['../structnvtx_event_attributes__v2.html#aea6394028b2357cc25b41af32f9a7c8b',1,'nvtxEventAttributes_v2::messageType()'],['../structnvtx_resource_attributes__v0.html#a23bd2e672a9fe0b600e7d3599da7443a',1,'nvtxResourceAttributes_v0::messageType()'],['../structnvtx_sync_user_attributes__v0.html#ab31b719d75e5a4b64a7052327c2db023',1,'nvtxSyncUserAttributes_v0::messageType()']]]
];
