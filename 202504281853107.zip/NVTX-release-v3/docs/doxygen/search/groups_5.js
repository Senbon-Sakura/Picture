var searchData=
[
  ['string_20registration_0',['String Registration',['../group___s_t_r_i_n_g___r_e_g_i_s_t_r_a_t_i_o_n.html',1,'']]],
  ['synchronization_1',['Synchronization',['../group___s_y_n_c_h_r_o_n_i_z_a_t_i_o_n.html',1,'']]]
];
