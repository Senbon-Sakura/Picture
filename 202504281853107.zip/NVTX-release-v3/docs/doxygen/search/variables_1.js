var searchData=
[
  ['identifiertype_0',['identifierType',['../structnvtx_resource_attributes__v0.html#acec361e5bafce002e93a604e36bdf31b',1,'nvtxResourceAttributes_v0']]]
];
