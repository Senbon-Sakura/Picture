Installation
============

``nvtx`` requires Python >=3.6,<3.10, and is tested on Linux only.

Install using `conda` (preferred):
::

   conda install -c conda-forge nvtx

Install using `pip`:
::

   python -m pip install nvtx

Or `conda`:
::

   conda install -c conda-forge nvtx
