Reference
=========

.. automodule:: nvtx.nvtx
   :members:
