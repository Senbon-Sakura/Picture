.. toctree::
   :maxdepth: 2

   install
   annotate
   auto
   reference
